package com.main.about;
public class Food implements Resturant {
	
	  public void  Vegbuff()
	  {
		  System.out.println("Veg price is : 500rs");
	  }

	  public void nonvegbuff()
	  {
		  System.out.println("nonveg price is : 750rs");
	  }
	  
}
